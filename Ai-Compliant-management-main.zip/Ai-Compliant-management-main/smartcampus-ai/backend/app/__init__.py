# SmartCampus AI — Backend Application
